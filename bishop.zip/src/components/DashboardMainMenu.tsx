import { useState, useEffect } from "react";
import { useWorkspaceStore } from "../stores/workspaceStore";
import {
  Plus,
  MoreHorizontal,
  User,
  Upload,
  FolderOpen,
  Trash2,
  X,
  HardDrive,
  Moon,
  Sun,
  Settings,
  ChevronDown,
  HelpCircle,
  Map,
  Grid
} from "lucide-react";
import { ARK_EXTENSION } from "../utils/arkPackage";
import { loadAppSettings, saveAppSettings } from "../utils/localStore";

export default function DashboardMainMenu({
  onEnterWorkspace,
}: {
  onEnterWorkspace: () => void;
}) {
  const store = useWorkspaceStore();

  const [activeCardMenuId, setActiveCardMenuId] = useState<string | null>(null);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newBoardName, setNewBoardName] = useState("");
  const [importing, setImporting] = useState(false);

  // Default theme is dark ("Blackboard")
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Additional settings mirrors for unified UX
  const [showMiniMap, setShowMiniMap] = useState(false);
  const [showBg, setShowBg] = useState(true);
  const [settingsLoaded, setSettingsLoaded] = useState(false);

  useEffect(() => {
    store.loadWorkspacesMenu();
  }, []);

  useEffect(() => {
    let cancelled = false;

    const loadSavedSettings = async () => {
      const saved = await loadAppSettings();
      if (cancelled) return;

      setIsDarkMode(saved.isDarkMode);
      setShowMiniMap(saved.showMiniMap);
      setShowBg(saved.showBg);
      setSettingsLoaded(true);
    };

    loadSavedSettings().catch((err) => {
      console.warn("[Dashboard] Failed to load saved UI settings:", err);
      if (!cancelled) setSettingsLoaded(true);
    });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!settingsLoaded) return;

    saveAppSettings({
      isDarkMode,
      showMiniMap,
      showBg,
    }).catch((err) => {
      console.error("[Dashboard] Failed to persist UI settings:", err);
    });
  }, [settingsLoaded, isDarkMode, showMiniMap, showBg]);

  const handleCreateWorkspace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBoardName.trim()) return;

    await store.createWorkspace(newBoardName.trim());
    setNewBoardName("");
    setIsCreateModalOpen(false);
    onEnterWorkspace();
  };

  const handleImport = async () => {
    setImporting(true);
    try {
      const success = await store.importWorkspace();
      if (success) {
        onEnterWorkspace();
      }
    } finally {
      setImporting(false);
    }
  };

  const handleSelectWorkspace = async (id: string) => {
    await store.switchWorkspace(id);
    onEnterWorkspace();
  };

  return (
    <div
      onClick={() => {
        setIsProfileMenuOpen(false);
        setActiveCardMenuId(null);
      }}
      className={`min-h-screen w-full font-sans flex flex-col antialiased select-none transition-colors duration-200 ${
        isDarkMode ? "bg-[#0c0f14] text-slate-100" : "bg-[#eaedef] text-slate-800"
      }`}
    >
      {/* Top Header Bar */}
      <header
        className={`h-14 px-6 flex items-center justify-between border-b transition-colors ${
          isDarkMode ? "border-slate-800/80 bg-[#11151d]" : "border-slate-300/40 bg-transparent"
        }`}
      >
        <div className="flex items-center gap-2">
          <div className="text-sm font-bold tracking-tight flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 inline-block shadow-xs shadow-indigo-500/50" />
            <span className={isDarkMode ? "text-slate-200" : "text-slate-700"}>
              Blackboard Workspace
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Import Package Button */}
          <button
            onClick={handleImport}
            disabled={importing}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold shadow-xs transition-colors cursor-pointer disabled:opacity-50 ${
              isDarkMode
                ? "bg-[#181d28] border-slate-700 text-slate-200 hover:bg-[#202736]"
                : "bg-white border-slate-300 text-slate-700 hover:bg-slate-50"
            }`}
            title={`Import .${ARK_EXTENSION} package`}
          >
            <Upload size={14} />
            <span>{importing ? "Importing..." : `Import .${ARK_EXTENSION}`}</span>
          </button>

          {/* Unified Profile & Settings Trigger */}
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsProfileMenuOpen(!isProfileMenuOpen);
              }}
              className={`flex items-center gap-2 p-1 pl-1.5 pr-2.5 rounded-full border transition-all cursor-pointer ${
                isDarkMode
                  ? "bg-[#181d28] border-slate-700 hover:border-slate-500 text-slate-200"
                  : "bg-white border-slate-300 hover:border-slate-400 text-slate-700"
              }`}
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-indigo-500 to-rose-400 p-0.5 shadow-xs flex items-center justify-center">
                <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center text-white text-xs font-bold">
                  <User size={13} />
                </div>
              </div>
              <span className="text-xs font-semibold">Account</span>
              <ChevronDown size={13} className="opacity-60" />
            </button>

            {/* Profile & Settings Combined Dropdown */}
            {isProfileMenuOpen && (
              <div
                onClick={(e) => e.stopPropagation()}
                className={`absolute right-0 top-full mt-2 w-64 rounded-2xl border shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 duration-100 ${
                  isDarkMode
                    ? "bg-[#181c24] border-slate-700/80 text-slate-200"
                    : "bg-white border-slate-200 text-slate-800"
                }`}
              >
                {/* User Info Header */}
                <div className="px-3.5 py-2 border-b border-slate-800 flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white font-bold text-xs shadow-inner">
                    <User size={14} />
                  </div>
                  <div className="overflow-hidden">
                    <div className="font-semibold text-slate-100 truncate">Creator Workspace</div>
                    <div className="text-[10px] text-slate-400 truncate">Local Session Profile</div>
                  </div>
                </div>

                {/* Preferences Section */}
                <div className="py-1">
                  <div className="px-3.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mt-1">
                    <Settings size={10} /> Essential Preferences
                  </div>

                  {/* Theme Switcher Toggle */}
                  <button
                    onClick={() => setIsDarkMode(!isDarkMode)}
                    className="w-full text-left px-3.5 py-2 hover:bg-slate-800/80 flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2 text-slate-300">
                      {isDarkMode ? <Moon size={13} className="text-indigo-400" /> : <Sun size={13} className="text-amber-500" />}
                      Dark Theme Mode
                    </span>
                    <div className={`w-8 h-4 flex items-center rounded-full p-0.5 transition-colors ${isDarkMode ? "bg-indigo-600 justify-end" : "bg-slate-700 justify-start"}`}>
                      <div className="bg-white w-3 h-3 rounded-full shadow-md" />
                    </div>
                  </button>

                  <button
                    onClick={() => setShowMiniMap(!showMiniMap)}
                    className="w-full text-left px-3.5 py-2 hover:bg-slate-800/80 flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2 text-slate-300">
                      <Map size={13} className="text-emerald-400" /> Canvas MiniMap
                    </span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${showMiniMap ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-800 text-slate-500"}`}>
                      {showMiniMap ? "ON" : "OFF"}
                    </span>
                  </button>

                  <button
                    onClick={() => setShowBg(!showBg)}
                    className="w-full text-left px-3.5 py-2 hover:bg-slate-800/80 flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2 text-slate-300">
                      <Grid size={13} className="text-sky-400" /> Grid Background
                    </span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${showBg ? "bg-sky-500/20 text-sky-400" : "bg-slate-800 text-slate-500"}`}>
                      {showBg ? "ON" : "OFF"}
                    </span>
                  </button>
                </div>

                <div className="my-1 border-t border-slate-800" />

                {/* Management Section */}
                <div className="py-1">
                  <div className="px-3.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <HardDrive size={10} /> Storage & System
                  </div>

                  <div className="px-3.5 py-1.5 text-[11px] text-slate-400 flex items-center gap-2">
                    <HardDrive size={13} className="text-indigo-400 shrink-0" />
                    <span>Saved locally to app disk / storage.</span>
                  </div>
                </div>

                <div className="my-1 border-t border-slate-800" />

                {/* Footer Utilities */}
                <div className="py-1">
                  <button
                    onClick={() => {
                      alert("ArkBishop Workspace Engine v1.0. All changes are saved locally.");
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full text-left px-3.5 py-1.5 hover:bg-slate-800/80 flex items-center gap-2 text-slate-400 transition-colors cursor-pointer"
                  >
                    <HelpCircle size={13} />
                    <span>About Workspace</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Board Grid */}
      <main className="flex-1 p-8 max-w-[1700px] w-full mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-5">
          
          {/* New Blackboard Button Tile */}
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="group relative aspect-[16/10] bg-[#1a73e8] hover:bg-[#1557b0] text-white rounded-2xl shadow-xs hover:shadow-md transition-all flex flex-col items-center justify-center gap-3 p-4 cursor-pointer overflow-hidden active:scale-[0.98]"
          >
            <div className="w-12 h-12 rounded-full bg-white/20 group-hover:bg-white/30 flex items-center justify-center transition-colors">
              <Plus size={28} strokeWidth={2.5} className="text-white" />
            </div>
            <span className="text-xs font-bold tracking-tight">New Blackboard</span>
          </button>

          {/* Local Boards List */}
          {store.workspacesList.map((ws) => {
            const isSelected = ws.id === store.currentWorkspaceId;

            return (
              <div
                key={ws.id}
                onClick={() => handleSelectWorkspace(ws.id)}
                className={`group relative aspect-[16/10] rounded-2xl shadow-xs hover:shadow-md transition-all border flex flex-col overflow-hidden cursor-pointer ${
                  isDarkMode
                    ? "bg-[#161a23] border-slate-800 hover:border-slate-700"
                    : "bg-white border-slate-200 hover:border-slate-300"
                } ${isSelected ? "ring-2 ring-[#1a73e8] border-transparent" : ""}`}
              >
                {/* Thumbnail Preview Area */}
                <div className="flex-1 bg-[#090b0f] relative overflow-hidden flex items-center justify-center">
                  {ws.thumbnail ? (
                    <img src={ws.thumbnail} alt={ws.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-slate-600 gap-1">
                      <HardDrive size={18} className="opacity-40" />
                      <span className="text-[9px] uppercase tracking-wider font-mono opacity-50">Local Board</span>
                    </div>
                  )}
                </div>

                {/* Card Footer */}
                <div
                  className={`h-14 px-3.5 flex items-center justify-between border-t ${
                    isDarkMode ? "bg-[#161a23] border-slate-800/80" : "bg-white border-slate-100"
                  }`}
                >
                  <div className="flex flex-col min-w-0 pr-2">
                    <span className={`text-xs font-bold truncate leading-snug ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
                      {ws.name || "Untitled"}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium truncate mt-0.5">
                      Edited: {ws.updatedAt ? new Date(ws.updatedAt).toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" }) : "Recently"}
                    </span>
                  </div>

                  {/* Actions Dropdown */}
                  <div className="relative shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveCardMenuId(activeCardMenuId === ws.id ? null : ws.id);
                      }}
                      className={`p-1 rounded-md transition-colors ${
                        isDarkMode
                          ? "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                          : "text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                      }`}
                    >
                      <MoreHorizontal size={16} />
                    </button>

                    {activeCardMenuId === ws.id && (
                      <div
                        className={`absolute right-0 bottom-full mb-2 w-36 rounded-xl shadow-xl py-1 z-20 text-xs font-medium border animate-in fade-in zoom-in-95 duration-100 ${
                          isDarkMode
                            ? "bg-[#1c222e] border-slate-700 text-slate-200"
                            : "bg-white border-slate-200 text-slate-700"
                        }`}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => {
                            setActiveCardMenuId(null);
                            handleSelectWorkspace(ws.id);
                          }}
                          className={`w-full text-left px-3 py-1.5 flex items-center gap-2 transition-colors ${
                            isDarkMode ? "hover:bg-slate-800" : "hover:bg-slate-100"
                          }`}
                        >
                          <FolderOpen size={13} />
                          <span>Open Board</span>
                        </button>
                        <button
                          onClick={async () => {
                            setActiveCardMenuId(null);
                            await store.deleteWorkspace(ws.id);
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-rose-500/10 text-rose-500 flex items-center gap-2 transition-colors"
                        >
                          <Trash2 size={13} />
                          <span>Delete</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

        </div>
      </main>

      {/* New Board Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div
            className={`w-full max-w-sm rounded-2xl p-5 shadow-2xl border ${
              isDarkMode ? "bg-[#161a23] border-slate-700 text-slate-100" : "bg-white border-slate-200 text-slate-800"
            }`}
          >
            <div className={`flex items-center justify-between border-b pb-3 ${isDarkMode ? "border-slate-800" : "border-slate-100"}`}>
              <h3 className="text-sm font-bold">Create New Blackboard</h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-200 transition-colors"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateWorkspace} className="mt-4 flex flex-col gap-4">
              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Board Title
                </label>
                <input
                  type="text"
                  autoFocus
                  placeholder="e.g. System Architecture"
                  value={newBoardName}
                  onChange={(e) => setNewBoardName(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg text-xs outline-none transition-colors ${
                    isDarkMode
                      ? "bg-[#0c0f14] border-slate-700 text-white focus:border-[#1a73e8]"
                      : "bg-white border-slate-300 text-slate-800 focus:border-[#1a73e8]"
                  }`}
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold opacity-70 hover:opacity-100 transition-opacity"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newBoardName.trim()}
                  className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-[#1a73e8] hover:bg-[#1557b0] text-white disabled:opacity-50 transition-colors shadow-xs"
                >
                  Create Board
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}